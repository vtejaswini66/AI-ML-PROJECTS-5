import yfinance as yf
import numpy as np

from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

model = load_model("models/lstm_model.h5")

data = yf.download("AAPL", period="3mo")

close = data["Close"].values.reshape(-1,1)

scaler = MinMaxScaler()

scaled = scaler.fit_transform(close)

last_60 = scaled[-60:]

X = np.array([last_60])

prediction = model.predict(X)

print("Realtime prediction:", prediction)