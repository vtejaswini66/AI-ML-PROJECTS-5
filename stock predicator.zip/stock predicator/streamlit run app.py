import streamlit as st
import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

st.title("📈 Stock Price Trend Prediction (LSTM)")

# Load trained model
model = load_model("models/lstm_model.h5")

uploaded_file = st.file_uploader("Upload Stock Dataset (CSV)", type=["csv"])

if uploaded_file is not None:

    data = pd.read_csv(uploaded_file)

    st.subheader("Dataset Preview")
    st.write(data.tail())

    if "Close" not in data.columns:
        st.error("Dataset must contain a 'Close' column.")
    else:

        # Clean Close column
        data["Close"] = pd.to_numeric(data["Close"], errors="coerce")
        data = data.dropna()

        close_prices = data["Close"].values.reshape(-1,1)

        scaler = MinMaxScaler()
        scaled_data = scaler.fit_transform(close_prices)

        if len(scaled_data) < 60:
            st.error("Dataset must contain at least 60 rows.")
        else:

            last_60_days = scaled_data[-60:]
            X_test = np.array([last_60_days])

            if st.button("Predict Next Day Price"):

                prediction = model.predict(X_test)

                predicted_price = scaler.inverse_transform(prediction)

                st.success(f"Predicted Next Day Stock Price: {predicted_price[0][0]:.2f}")