import numpy as np
import pandas as pd

from sklearn.metrics import mean_squared_error
from tensorflow.keras.models import load_model

data = pd.read_csv("dataset/stock_data.csv")

model = load_model("models/lstm_model.h5")

print("Model loaded successfully")

# Simple evaluation placeholder
print("Evaluation complete")