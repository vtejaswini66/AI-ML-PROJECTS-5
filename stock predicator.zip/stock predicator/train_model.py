import numpy as np
import pandas as pd
import os

from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

print("Starting training process...")

# Load dataset
data = pd.read_csv("dataset/stock_data.csv")

print("Original Columns:", data.columns)

# Remove rows that contain text like AAPL
data = data[data["Close"] != "AAPL"]

# Convert Close column to numeric
data["Close"] = pd.to_numeric(data["Close"], errors="coerce")

# Drop invalid rows
data = data.dropna()

print("Cleaned dataset preview:")
print(data.head())

close_prices = data["Close"].values.reshape(-1,1)

scaler = MinMaxScaler()

scaled_data = scaler.fit_transform(close_prices)

X = []
y = []

for i in range(60, len(scaled_data)):
    X.append(scaled_data[i-60:i])
    y.append(scaled_data[i])

X = np.array(X)
y = np.array(y)

print("Dataset prepared")

model = Sequential()

model.add(LSTM(50, return_sequences=True, input_shape=(X.shape[1],1)))
model.add(LSTM(50))
model.add(Dense(1))

model.compile(optimizer="adam", loss="mean_squared_error")

print("Training model...")

model.fit(X, y, epochs=3, batch_size=32)

# Create models folder
if not os.path.exists("models"):
    os.makedirs("models")

model.save("models/lstm_model.h5")

print("Training completed successfully!")