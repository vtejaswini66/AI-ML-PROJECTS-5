import yfinance as yf
import pandas as pd
import os

print("Starting dataset download...")
if not os.path.exists("dataset"):
    os.makedirs("dataset")
    print("Dataset folder created")

# Download stock data
data = yf.download("AAPL", start="2015-01-01", end="2024-01-01")

print("Download complete!")

# Save dataset
data.to_csv("dataset/stock_data.csv")

print("Dataset saved successfully!")
print(data.head())