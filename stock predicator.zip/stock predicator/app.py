import os
import streamlit as st
import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

# Optional: hide TensorFlow warnings
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

st.title("📈 Stock Price Trend Prediction")

# Load model safely
try:
    model = load_model("models/lstm_model.h5")
except:
    st.error("Model file not found. Make sure 'models/lstm_model.h5' exists.")
    st.stop()

# Upload CSV
file = st.file_uploader("Upload Stock Dataset (.csv)", type=["csv"])

if file is not None:

    # FIXED LINE (auto detect CSV separator)
    data = pd.read_csv(file, sep=None, engine="python")

    st.subheader("Dataset Preview")
    st.write(data.tail())

    st.subheader("Dataset Columns")
    st.write(list(data.columns))

    # Clean column names
    data.columns = data.columns.str.strip().str.lower()

    # Detect closing price column
    if "close" in data.columns:
        close_column = "close"
    elif "adj close" in data.columns:
        close_column = "adj close"
    else:
        st.error("Dataset must contain a 'Close' or 'Adj Close' column.")
        st.stop()

    close_prices = data[close_column].dropna().values.reshape(-1,1)

    if len(close_prices) < 60:
        st.error("Dataset must contain at least 60 rows for prediction.")
        st.stop()

    scaler = MinMaxScaler(feature_range=(0,1))
    scaled_data = scaler.fit_transform(close_prices)

    last_60_days = scaled_data[-60:]
    X_test = np.array([last_60_days])

    if st.button("Predict Next Day Price"):

        prediction = model.predict(X_test)
        predicted_price = scaler.inverse_transform(prediction)

        st.success(f"Predicted Next Day Price: ${predicted_price[0][0]:.2f}")