import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

print("Loading trained model...")

# Load trained model
model = load_model("models/lstm_model.h5")

print("Model loaded successfully")

# Read dataset (skip the first 2 wrong rows)
data = pd.read_csv("dataset/stock_data.csv", skiprows=2)

# Rename columns properly
data.columns = ["Date", "Close", "High", "Low", "Open", "Volume"]

print("Dataset loaded successfully")
print(data.head())

# Convert Close column to numeric
data["Close"] = pd.to_numeric(data["Close"], errors="coerce")

# Remove invalid rows
data = data.dropna()

# Extract Close prices
close_prices = data["Close"].values.reshape(-1, 1)

# Scale data
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(close_prices)

# Use last 60 days for prediction
last_60_days = scaled_data[-60:]

X_test = np.array([last_60_days])

print("Predicting next stock price...")

# Predict
prediction = model.predict(X_test)

# Convert back to real price
predicted_price = scaler.inverse_transform(prediction)

print("\nPredicted Next Day Stock Price:")
print(float(predicted_price[0][0]))